#ifndef Clock_h
#define Clock_h
#include "Arduino.h"
#include <LiquidCrystal_I2C.h>


class Clock {
  private:
    LiquidCrystal_I2C lcd; // objeto lcd que será utilizado para mostrar datos del modulo RTC
  public:
    Clock (LiquidCrystal_I2C &lcd); //constructor del objeto
    void DS1307_read(); //Usado para leer los valores del módulo RTC
    void DS1307_display(); //Visualiza en el lcd los datos obtenidos de la hora del módulo RTC
    void calendar_display(); //Visualiza en lcd los datos obtenidos de la fecha del módulo RTC
    void showTimeMessage(uint8_t hour,uint8_t minute);
    //getters
    byte getSecond();
    byte getMinute();
    byte getHour();
    byte getDate();
    byte getMonth();
    byte getYear();
};
#endif
