#include "Arduino.h"
#include <LiquidCrystal_I2C.h>
#include "Clock.h"
#include "RTClib.h"

char Time_[] =   "TIME:   :  :  "; //Arreglo de caracteres que representa la hora actual
char Date_[] =   "DATE:   /  /20  "; //Arreglo de caracteres que representa la fecha actual
byte i_, second_, minute_, hour_, date_, month_;//Usados para obtener y asignar los valores del modulo RTC
int year_ = 0;//Año del RTC
RTC_DS1307 rtc_; //objeto del módulo RTC

Clock::Clock (LiquidCrystal_I2C &lcd) : lcd(lcd) {  //constructor para el objeto, que recibe un objeto lcd inicializado en el main principal

}
void Clock::DS1307_read(){ //lee los valores del modulo RTC
   DateTime now = rtc_.now();
   second_ = now.second();
   minute_ = now.minute();
   hour_ = now.hour();
   date_ = now.day(); //week day
   //date = Wire.read();
   month_ = now.month();
   year_ = now.year() - 2000;
}
void Clock::showTimeMessage(uint8_t hour,uint8_t minute){
  Time_[13] = 0 % 10 + 48;
  Time_[12] = 0 / 10 + 48;
  //:
  Time_[10] = minute % 10 + 48;
  Time_[9] = minute / 10 + 48;
  //:
  Time_[7] = hour % 10 + 48;
  Time_[6] = hour / 10 + 48;
  lcd.setCursor(0, 0);
  lcd.print(Time_);
}
void Clock::DS1307_display(){ //Visualiza en el lcd los valores obtenidos de la hora del móudlo RTC
    Time_[13] = second_ % 10 + 48;
    Time_[12] = second_ / 10 + 48;
    //:
    Time_[10] = minute_ % 10 + 48;
    Time_[9] = minute_ / 10 + 48;
    //:
    Time_[7] = hour_ % 10 + 48;
    Time_[6] = hour_ / 10 + 48;
    lcd.setCursor(0, 0);
    lcd.print(Time_);
}
void Clock::calendar_display(){ //visualiza los valroes de la fecha obtenidos del módulo RTC
    char bufferFecha[12];
    sprintf(bufferFecha, "%02d/%02d/20%02d", date_, month_, year_);
    lcd.setCursor(0, 1);
    lcd.print("DATE:");
    lcd.setCursor(6, 1);
    lcd.print(bufferFecha);
}
//getters
byte Clock::getMinute() {
    return minute_;
}
byte Clock::getHour() {
    return hour_;
}
byte Clock::getSecond() {
    return second_;
}
byte Clock::getMonth() {
    return month_;
}
byte Clock::getDate() {
    return date_;
}
byte Clock::getYear() {
    return year_;
}
