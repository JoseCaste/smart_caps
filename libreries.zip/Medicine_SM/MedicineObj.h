#ifndef Animal_h
#define Animal_h
#include "Arduino.h"
class MedicineObj{
    public:
      uint8_t id;
      uint8_t hour_;
      uint8_t minute_;
      uint8_t inter_;
      MedicineObj();
};
#endif
