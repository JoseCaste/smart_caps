#include "Arduino.h"
#include <LiquidCrystal_I2C.h>
#include "Medicine.h"
#include "RTClib.h"
#include <EEPROM.h>
#include <LinkedList.h>
#include "MedicineObj.h"
/**
Línea 12 a 18
Estructura usada para almacenar los datos de la medicine a guardar
*/
struct Medicine_str {
  uint8_t id; //identificador
  uint8_t hour_; //hora de notificación
  uint8_t minute_;//minuto de notificación
  uint8_t inter_; //intervalo de cada toma -- 2,4,6,8,10,12,14,16,18,20,22,24 hrs

};
#define A 7
#define B 8
#define C 9
#define D 10
#define E 11
#define F 12
#define G 13
#define BUZZER 2
char Interval_[] = "INTE:   hrs"; //mensaje a mostrar en el lcd
const int pins[7] = { A, B, C, D, E, F, G }; //segmentos asociados a los pines
const byte numbersDisplayAnode[10] = {0b0111111,     //0
                            0b0000110,          //1
                            0b1011011,          //2
                            0b1001111,          //3
                            0b1100110,          //4
                            0b1101101,          //5
                            0b1111101,          //6
                            0b0000111,          //7
                            0b1111111,          //8
                            0b1101111};         //9
byte hour_interval_ = 2; //hora a mostar, inciada en 2
uint8_t id_medicine_ = 0;
int eeprom_adr = 0; //dirección inicial de la memoria eeprom

Medicine::Medicine (LiquidCrystal_I2C &lcd) : lcd(lcd) {
  /*Método usado para inicializar los pines de salida para el display 7 segmentos*/
  for(int i = 0; i < 7; i++) {
      pinMode(pins[i], OUTPUT);
    }
    pinMode(BUZZER,OUTPUT);
}
void Medicine::interval_display() {
  //muestra en el lcd el intervalo como mensaje y las horas de intervalo
  char buffer[2];
  lcd.setCursor(0, 1);
  lcd.print("INTE");
  sprintf(buffer, "%02d", hour_interval_);
  lcd.setCursor(6, 1);
  lcd.print(buffer);
}
void Medicine::id_display() {
  lcd.setCursor(9, 1);
  lcd.print("ID:");
  lcd.print(id_medicine_);
}
void Medicine::addMedicine(Medicine_str &medicine){
      Serial.print("ID: ");
      Serial.println(medicine.id);
      Serial.print("Hour: ");
      Serial.println(medicine.hour_);
      Serial.print("Minute: ");
      Serial.println(medicine.minute_);
      Serial.print("Interval: ");
      Serial.println(medicine.inter_);
      // Escribiendo datos
      EEPROM.put(eeprom_adr, medicine); //eeprom_adr tiene la ultima posición de la memoria eeprom, despues de leer los datos de este
      Serial.println("¡Datos escritos!");
}
uint8_t Medicine::getMedicineId(){
  return id_medicine_;
}
byte Medicine::getHourInterval(){
  return hour_interval_;
}
void Medicine::readAllMedicines(){
 /*Lee todas las direcciones de la memoria eeprom
Cada esctructura abarca un total de 4 posiciones en la memoria eeprom, esto puede variar segun el numero de atributos
 */
 bool flag = true; //bandera para continuar o interrumpir el bucle de la lectura de la memoria eeprom, ya que por defecto la memoria eeprom retorna siempre 0 los valores no escritos.
 uint8_t id_aux; //auxiliar para ayudar a detectar cuando no se ha detectado cambios en la memoria eeprom, es decir, un id=8 y al siguiente bucle será 0, si es 0, rompe la iteración
 eeprom_adr=0; //reinicia las direcciones de la memoria eeprom
 while (flag) {
   Serial.println("**************");
   Medicine_str medicine;
   EEPROM.get(eeprom_adr, medicine);
   if ( medicine.id != 0 ) {
     id_aux = medicine.id;
     Serial.print("ID: ");
     Serial.println(medicine.id);
     Serial.print("Hour: ");
     Serial.println(medicine.hour_);
     Serial.print("Minute: ");
     Serial.println(medicine.minute_);
     Serial.print("Interval: ");
     Serial.println(medicine.inter_);
     eeprom_adr += sizeof(medicine);
   } else flag = false;
 }
 //return init_index;
}
LinkedList<MedicineObj*> Medicine::getArrayMedicines(byte hour_){
    LinkedList<MedicineObj*> myList= LinkedList<MedicineObj*>();
    return myList;
}
void Medicine::getArrayMedicines_(byte hour_, byte minute_){
    eeprom_adr=0;
    bool flag = true;
    uint8_t id_aux;
    while (flag) {
      Medicine_str medicine;
      EEPROM.get(eeprom_adr, medicine);
      if ( medicine.id != 0 ) {
        id_aux = medicine.id;
        Serial.println(medicine.id);
        if(medicine.hour_ == hour_ && medicine.minute_ == minute_){ //valida si la hora actual es la misma a la hora del medicamento
          lightSegments(medicine.id); //Enciende el display 7 segmentos con el id del medicamento
          if(digitalRead(BUZZER) == LOW)
          digitalWrite(BUZZER,HIGH);
          delay(4000); //delay provisional
          shutDownMedicine(); //apaga el display 7 segmentos
        }else if(digitalRead(BUZZER)==HIGH) digitalWrite(BUZZER,LOW);
        eeprom_adr += sizeof(medicine); //incremente a la siguiente estructura el indice de la memoria eeprom
      } else flag = false;
    }
}
void Medicine::updateMedicine(Medicine_str &medicine_update){
  eeprom_adr=0;
  bool flag = true;
  uint8_t id_aux;
  while (flag) {
    Medicine_str medicine;
    EEPROM.get(eeprom_adr, medicine);
    if ( medicine.id != 0 ) {
      id_aux = medicine.id;
      Serial.println(medicine.id);
      if(medicine.id == medicine_update.id){
          Serial.print("Actualizado ");
          Serial.print(medicine.id);
          Serial.print(" ");
          Serial.print(medicine.hour_);
          Serial.print(" ");
          Serial.print(medicine.minute_);
          Serial.println("");
          //medicine=medicine_update;
          EEPROM.put(eeprom_adr,medicine_update);
          break;
      }
      eeprom_adr += sizeof(medicine); //incremente a la siguiente estructura el indice de la memoria eeprom
    } else flag = false;
  }
}
void Medicine::deleteMedicine(uint8_t id_medicine_){
  
}
Medicine_str Medicine::searchMedicine(uint8_t id_medicine){
  eeprom_adr=0;
  bool flag = true;
  uint8_t id_aux;
  Medicine_str medicine_;
  while (flag) {
    Medicine_str medicine;
    EEPROM.get(eeprom_adr, medicine);
    if ( medicine.id != 0 ) {
      id_aux = medicine.id;
      Serial.println(medicine.id);
      if(medicine.id == id_medicine){
          Serial.print("Encontrado ");
          Serial.print(medicine.id);
          Serial.print(" ");
          Serial.print(medicine.hour_);
          Serial.print(" ");
          Serial.print(medicine.minute_);
          medicine_=medicine;
          break;
      }
      eeprom_adr += sizeof(medicine); //incremente a la siguiente estructura el indice de la memoria eeprom
    } else flag = false;
  }
  return medicine_;
}
void Medicine::lightSegments(uint8_t number) {
  byte numberBit = numbersDisplayAnode[number];
  for (int i = 0; i < 7; i++)  {
    int bit = bitRead(numberBit, i);
    digitalWrite(pins[i], bit);
  }
}
void Medicine::shutDownMedicine(){
  for (int i = 0; i < 7; i++)  {
    digitalWrite(pins[i], LOW);
  }
}
