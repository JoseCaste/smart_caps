#include "MedicineObj.h"
#include "Arduino.h"
MedicineObj::MedicineObj(){

}
