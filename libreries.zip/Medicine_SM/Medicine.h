#ifndef Medicine_h
#define Medicine_h
#include "Arduino.h"
#include <LiquidCrystal_I2C.h>
#include <LinkedList.h>
#include "MedicineObj.h"
struct Medicine_str;
typedef struct Medicine_str medicine;
class Medicine{
private:
  LiquidCrystal_I2C lcd;
public:
  Medicine(LiquidCrystal_I2C &lcd); //constructor que recibe el objeto lcd inicializado del programa .ino
  void interval_display(); //visualiza en el lcd el mensaje y valor del intervalo de cada toma del medicamento
  void id_display(); //visualiza el id por defecto y/o modificado en la misma ejecución del sistema
  void addMedicine(Medicine_str &medicine); //Recibe una estructura que guarda la medicina en la memoria eeprom
  byte getHourInterval(); //getter
  uint8_t getMedicineId();  //getter
  void readAllMedicines();
  LinkedList<MedicineObj*> getArrayMedicines(byte hour_); //Método a discutir con el asesor
  void getArrayMedicines_(byte hour_, byte minute_);//verifica qué medicinas es necesario notificar la usuario
  void lightSegments(byte number); //Enciende el display 7 segmentos
  void shutDownMedicine();  //Apaga el display 7 segmentos
  void updateMedicine(Medicine_str &medicine); //Actualiza el la estructura para guardarla en la memoria eeprom
  void deleteMedicine(uint8_t id_medicine_);
  Medicine_str searchMedicine(uint8_t id_medicine);
};
#endif
